var Public = Public || {};
Public.initCKPlayer = function (cId, url){
	if ($("#" + cId).length == 0 || !url){
		return;
	}
	var flashvars = {
        p: 0,
        e: 2,
    };
    var video = [url, 'http://www.ckplayer.com/webm/0.webm->video/webm', 'http://www.ckplayer.com/webm/0.ogv->video/ogg'];
    var support = ['all'];
    CKobject.embedHTML5(cId, 'ckplayer_a1', "100%", 145, video, flashvars, support);
};

$(function(){
	
	/*
	//菜单下拉
	var flag = 1
	$(".header-sort").tap(function(){
		if(flag){
			$(this).children("i").html("&#xe60b;");
			$("#menu").show();
			flag = 0;
		}else{
			$(this).children("i").html("&#xe602;");
			$("#menu").hide();
			flag =1;
		}
	})	
	$("#menu>li").each(function(i){
		$(this).tap(function(){
			$(this).children('ul').show().parent().siblings().children("ul").hide();
		})
	}).eq(0).trigger("tap");
	
	$(".navTab li").tap(function(){
		var i = $(this).index()
		$(this).addClass("active").siblings().removeClass("active")
		$(".tabCharts li").eq(i).show().siblings().hide()
	}).eq(0).trigger("tap")
	
	//返回顶部
	if($(".toUp").length==0){
		$("body").append('<div class="toUp"><i class="ui-font icon-top-copy"></i><span>顶部</span></div>')
	}
	$(window).scroll(function(){
		var top = $(window).scrollTop()
		if(top>=100){
			$(".toUp").show()
		}else{
			$(".toUp").hide()
		}
	})
	$(".toUp").tap(function(){
		$("html,body").scrollTop(0);
	})
	*/
	
	//自定义模块
	//提示弹窗( 注意：.centerPanel弹窗居中显示, .footerPanel底部提示弹窗)
	showPannel = {
		tipShow:function(obj){
			$(obj).addClass("show")
			$(".btnClose").click(function(){
				$(obj).removeClass("show");
			});
			$(".sBtn").click(function(){
				if(tag!=false){
					$(obj).removeClass("show");
				}
			});
			document.addEventListener('touchmove', function(event) {
				if(!$(obj).is(":hidden")){
					event.preventDefault();
				}
			})
		},
		customHtml:function(obj,infoTxt){
			$(obj).addClass("show");
			$(".btnClose").click(function(){
				$(obj).removeClass("show");
			});
			$(".sBtn").click(function(){
				if(tag!=false){
					$(obj).removeClass("show");
				}
			});
			$(obj).find(".info").html(infoTxt)
			document.addEventListener('touchmove', function(event) {
				if(!$(obj).is(":hidden")){
					event.preventDefault();
				}
			});
		}	
	};
	
	
})